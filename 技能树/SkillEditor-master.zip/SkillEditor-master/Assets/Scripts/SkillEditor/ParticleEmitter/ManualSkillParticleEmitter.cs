﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class ManualSkillParticleEmitter : SkillParticleEmitter {

	public override string displayName{
		get {  
			return "Particles";
		}
	}
}
