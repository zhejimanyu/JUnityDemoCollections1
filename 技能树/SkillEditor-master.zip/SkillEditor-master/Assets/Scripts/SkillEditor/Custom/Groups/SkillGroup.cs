﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TimeLine;

[TrackGroupAttribute("Skill Track Group", TimelineTrackGenre.SkillTrack)]
public class SkillGroup : ActorTrackGroup {

   

}
