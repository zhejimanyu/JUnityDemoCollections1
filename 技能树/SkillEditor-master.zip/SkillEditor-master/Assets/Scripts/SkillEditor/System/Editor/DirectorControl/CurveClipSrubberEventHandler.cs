﻿using System;
using System.Runtime.CompilerServices;

public delegate void CurveClipSrubberEventHandler(object sender, CurveClipScrubberEventArgs e);

