﻿using System;
using System.Runtime.CompilerServices;

public delegate void CurveClipWrapperEventHandler(object sender, CurveClipWrapperEventArgs e);

