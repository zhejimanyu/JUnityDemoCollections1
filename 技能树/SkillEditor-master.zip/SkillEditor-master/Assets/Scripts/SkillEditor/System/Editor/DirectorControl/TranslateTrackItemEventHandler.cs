﻿using System;
using System.Runtime.CompilerServices;

public delegate float TranslateTrackItemEventHandler(object sender, TrackItemEventArgs e);

