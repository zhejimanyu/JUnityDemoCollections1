﻿using System;
using System.Runtime.CompilerServices;

public delegate void ActionItemEventHandler(object sender, ActionItemEventArgs e);

