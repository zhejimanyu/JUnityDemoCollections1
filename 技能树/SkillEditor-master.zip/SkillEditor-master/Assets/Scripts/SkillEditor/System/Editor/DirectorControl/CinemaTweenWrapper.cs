﻿using System;
using UnityEngine;

public class CinemaTweenWrapper : CinemaActionWrapper
{
    public CinemaTweenWrapper(Behaviour behaviour, float firetime, float duration) : base(behaviour, firetime, duration)
    {
    }
}

