﻿namespace DirectorEditor
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void DirectorBehaviourControlHandler(object sender, DirectorBehaviourControlEventArgs e);
}

