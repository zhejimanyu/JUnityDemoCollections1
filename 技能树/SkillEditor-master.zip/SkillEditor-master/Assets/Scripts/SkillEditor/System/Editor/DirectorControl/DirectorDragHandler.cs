﻿using System;
using System.Runtime.CompilerServices;

public delegate void DirectorDragHandler(object sender, CinemaDirectorDragArgs e);

