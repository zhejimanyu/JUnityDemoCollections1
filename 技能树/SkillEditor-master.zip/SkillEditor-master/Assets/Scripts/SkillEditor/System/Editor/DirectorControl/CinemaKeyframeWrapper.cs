﻿using System;
using UnityEngine;

public class CinemaKeyframeWrapper
{
    internal Vector2 InTangentControlPointPosition;
    internal Vector2 OutTangentControlPointPosition;
    internal Vector2 ScreenPosition;
}

