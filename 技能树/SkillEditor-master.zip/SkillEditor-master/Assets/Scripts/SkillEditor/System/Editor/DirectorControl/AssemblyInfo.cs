﻿// Assembly DirectorEditor, Version 1.4.5.0

[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Reflection.AssemblyTitle("DirectorEditor")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCompany("Cinema Suite Inc")]
[assembly: System.Reflection.AssemblyProduct("DirectorEditor")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2015")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Runtime.InteropServices.Guid("8da53d6c-1afe-4371-9e52-1e09ee23536a")]
[assembly: System.Reflection.AssemblyFileVersion("1.4.5.0")]

