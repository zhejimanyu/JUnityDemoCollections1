﻿namespace DirectorEditor
{
    using System;

    public enum ResizeOption
    {
        Crop,
        Scale
    }
}

