﻿namespace DirectorEditor
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void SidebarControlHandler(object sender, SidebarControlEventArgs e);
}

