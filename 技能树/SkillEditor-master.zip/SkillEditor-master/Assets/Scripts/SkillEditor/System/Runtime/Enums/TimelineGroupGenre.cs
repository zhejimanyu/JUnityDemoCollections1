﻿
namespace TimeLine
{
    /// <summary>
    /// An enumeration of Track Genres.
    /// </summary>
    public enum TimelineGroupGenre
    {
        SkillTrackGroup,
        ActorTrackGroup
    }
}