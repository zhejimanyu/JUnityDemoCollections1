 switch (command)
        {
            case "init":
                break;
        }