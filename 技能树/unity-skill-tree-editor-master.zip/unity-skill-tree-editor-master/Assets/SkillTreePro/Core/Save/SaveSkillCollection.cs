﻿using UnityEngine;
using System.Collections;

namespace Adnc.SkillTree {
	public class SaveSkillCollection {
		public string uuid;
		public int skillIndex;
	}
}
