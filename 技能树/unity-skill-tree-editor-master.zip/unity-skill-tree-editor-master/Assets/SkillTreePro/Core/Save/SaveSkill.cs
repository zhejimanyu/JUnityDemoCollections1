﻿using UnityEngine;
using System.Collections;

namespace Adnc.SkillTree {
	public class SaveSkill {
		public string uuid;
		public bool unlocked;
	}
}

