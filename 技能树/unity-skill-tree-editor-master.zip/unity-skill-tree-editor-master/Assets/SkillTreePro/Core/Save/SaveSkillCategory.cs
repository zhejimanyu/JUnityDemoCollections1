﻿using UnityEngine;
using System.Collections;

namespace Adnc.SkillTree {
	public class SaveSkillCategory {
		public string uuid;
		public int skillLv;
	}
}

