﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Adnc.SkillTree {
	public class SkillCollectionGridItem {
		public SkillCollectionBase collection;
		public int x;
		public int y;
	}
}
