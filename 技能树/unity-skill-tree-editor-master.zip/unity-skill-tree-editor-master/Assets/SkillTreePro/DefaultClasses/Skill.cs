﻿using UnityEngine;
using System;
using System.Collections;

namespace Adnc.SkillTree {
	public class Skill : SkillBase {

	}
}
