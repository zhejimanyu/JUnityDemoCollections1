﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace Adnc.SkillTree {
	[AddComponentMenu("")]
	public class SkillCategory : SkillCategoryBase {

	}
}
