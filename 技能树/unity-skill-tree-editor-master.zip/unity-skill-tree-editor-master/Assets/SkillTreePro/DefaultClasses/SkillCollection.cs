﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

namespace Adnc.SkillTree {
	[AddComponentMenu("")]
	public class SkillCollection : SkillCollectionBase {

	}
}
