﻿using UnityEngine;
using System.Collections;

namespace Adnc.SkillTree.Example.MultiCategory {
	public enum NodeStatus {
		Locked,
		Purchasable,
		Unlocked
	}
}

