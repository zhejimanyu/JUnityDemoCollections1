# Unity Skill Tree Pro

Alpha Version 0.1

Unity custom graph editor for editing skill trees.

Live demo at https://dl.dropboxusercontent.com/u/26071528/skill%20tree%20example/index.html

* Create multiple custom skill trees for anything
* Simple, powerful, and customizable API for handling data
* Code is heavily documented
* Includes example implementations in the Examples folder
