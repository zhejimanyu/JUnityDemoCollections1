# FogOfWar
Unity implementation of a fog-of-war effect

See blog post at https://y4pp.wordpress.com/2020/02/09/fog-of-war/
