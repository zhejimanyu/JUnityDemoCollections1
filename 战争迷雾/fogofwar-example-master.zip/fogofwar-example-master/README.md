![alt text](https://github.com/Pjchardt/fogofwar-example/blob/master/screenshots/ExampleImage.jpg)

 # fogofwar-example
 Example of simple fog of war effect in Unity using a render texture and shader.
