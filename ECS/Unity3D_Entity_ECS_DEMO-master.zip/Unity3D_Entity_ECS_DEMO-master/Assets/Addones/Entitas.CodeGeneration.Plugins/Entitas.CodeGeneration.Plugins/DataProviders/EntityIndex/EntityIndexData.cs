﻿using DesperateDevs.CodeGeneration;

namespace Entitas.CodeGeneration.Plugins {

    public class EntityIndexData : CodeGeneratorData {
    }
}
