﻿using DesperateDevs.CodeGeneration;

namespace Entitas.CodeGeneration.Plugins {

    public class ContextData : CodeGeneratorData {
    }
}
