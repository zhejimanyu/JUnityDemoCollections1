﻿using System;

namespace Entitas.VisualDebugging.Unity {

    [AttributeUsage(AttributeTargets.Class)]
    public class DontDrawComponentAttribute : Attribute {
    }
}
