﻿using System;

namespace Entitas.CodeGeneration.Attributes {

    [AttributeUsage(AttributeTargets.Method)]
    public class EntityIndexGetMethodAttribute : Attribute {
    }
}
